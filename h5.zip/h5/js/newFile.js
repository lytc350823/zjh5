const { sayHello } = require("./app");

sayHello('VS Code');
